import flet as ft

def fun_page_collaboration(page: ft.Page):
    return ft.Column(
        controls=[
            ft.Text('Hello, page_collaboration!')
        ])
