import flet as ft
import requests

def fun_page_request(page: ft.Page):
    
    #Дополнительный контент для UI/UX
    username_ref = ft.Ref[ft.TextField]()
    number_ref1 = ft.Ref[ft.TextField]()
    email_ref2 = ft.Ref[ft.TextField]()
    question_ref = ft.Ref[ft.TextField]()
    
    
    #Функции для дополнительного контента
    def pressed_button_send_rq(e, number, email, username, question):
        data = f'Запрос на консультацию с MiniApp\n\nИмя клиента: {username}\nНомер телефона: {number}\nПочта: {email}\nВопрос от клиента: {question}'
        
        url = f'https://api.telegram.org/bot7281439549:AAFGdnV4SgCiHPQf25hnYtQG9tVl_yNMkJw/sendMessage?chat_id=-1002444207574&message_thread_id=3&text={data}'
        res = requests.post(url=url, json=data)
        if res.status_code == 200:
            print(f'Отправился запрос Боту')
        elif res.status_code == 404:
            print('Запрос Боту не отправлен')
        else:
            print('Другая ошибку. Проверить ссылку')
    
    
    
    
    return ft.Column(
        controls=[
            ft.ElevatedButton('Назад', color=ft.Colors.BLACK, bgcolor=ft.Colors.WHITE, icon=ft.Icons.ARROW_BACK, on_click=lambda e: page.go("/")),
            ft.Row(controls=[
                ft.Image(src=f"/sticker1.webp", width=40, height=40), 
                ft.Text('TechMind', italic=True)],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER),
            ft.Row(
            controls=[
                ft.Container(content=ft.Column(controls=[
                    ft.Text('Хотите обсудить ваш проект? Напишите нам!', width=250, color=ft.Colors.BLACK, size=20, weight=ft.FontWeight.W_600),
                    ft.TextField(hint_text='Ваше имя', width=250, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=username_ref),
                    ft.TextField(hint_text='Ваш номер телефона', width=250, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=number_ref1),
                    ft.TextField(hint_text='Ваш email', width=250, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=email_ref2),
                    ft.TextField(hint_text='Напишите какой вопрос вас интересует', width=250, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=question_ref, multiline=True),
                    ft.ElevatedButton('Отправить заявку', color=ft.Colors.WHITE, bgcolor=ft.Colors.BLACK, width=250, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0)), height=50, on_click=lambda e: pressed_button_send_rq(e, number_ref1.current.value, email_ref2.current.value, username_ref.current.value, question_ref.current.value))
                ]),
                            padding=20,
                            image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER),
                            border_radius=15,
                            bgcolor=ft.Colors.WHITE)
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            
        ),
        
        ])
