import flet as ft
import requests


def fun_page_request_TZ(page: ft.Page):
    page.window.width = 430
    page.window.height = 932
    #Дополнительный контент к основе (ПЕРЕМЕННЫЕ)
    username_ref = ft.Ref[ft.TextField]()
    number_ref1 = ft.Ref[ft.TextField]()
    email_ref2 = ft.Ref[ft.TextField]()
    question_ref = ft.Ref[ft.TextField]()
    custom_file_picker = ft.FilePicker(on_result=lambda e: on_files_selected(e))
    uploaded_files = []
    file_list = ft.Column()
    file_text_field = ft.TextField(
        hint_text='Ваше ТЗ',
        width=210,
        bgcolor=ft.Colors.WHITE,
        border_color=ft.Colors.GREY,
        value="",)
    snackbar_send_access = ft.SnackBar( 
                                       content=ft.Text('Отлично! Мы получили вашу заявку и в скором времени с вами свяжется наш менеджер', color=ft.Colors.BLACK),
                                       bgcolor='#EEC6FF',
                                       duration=10000,
                                       )
    
    
    
    #Дополнительный контент к основе (ФУНКЦИИ)
    def on_files_selected(e):
        if e.files:
            uploaded_files.clear()  # Очищаем список для работы с новым файлом
            for f in e.files:
                uploaded_files.append({"name": f.name, "path": f.path})
            update_file_list()
            update_text_field()  # Задаем новое значение в TextField
            page.update()
    
    
    def update_text_field():
    # Устанавливаем название файлов в TextField через запятую
        if uploaded_files:
            file_text_field.value = ", ".join([f["name"] for f in uploaded_files])
        else:
            file_text_field.value = ""
    
    
    def update_file_list():
        file_list.controls.clear()  # Очистить старый список
        for file in uploaded_files:
            file_list.controls.append(
                ft.Row(
                    [
                        ft.Text(file["name"], expand=True),  # Отображаем имя файла
                        ft.IconButton(
                            icon=ft.Icons.DELETE,
                            tooltip="Удалить",
                        ),
                    ]
                )
            )
        page.update()
    
    def open_custom_file_picker(e):
            custom_file_picker.pick_files(allow_multiple=True)
            page.update()
    

    
    
    def pressed_button_send_rq(e, number, email, username, question):
    # Отправка пользовательских данных
        data = f'Запрос на консультацию с MiniApp\n\nИмя клиента: {username}\nНомер телефона: {number}\nПочта: {email}\nВопрос от клиента: {question}'
        url_message = "https://api.telegram.org/bot7281439549:AAFGdnV4SgCiHPQf25hnYtQG9tVl_yNMkJw/sendMessage"
        
        response_message = requests.post(
            url=url_message, 
            params={
                "chat_id": "-1002444207574",
                "message_thread_id": "3",
                "text": data,
            }
        )
        if response_message.status_code == 200:
            print("Данные пользователя успешно отправлены!")
            snackbar_send_access.open = True
            page.update()
            
        else:
            print(f"Ошибка при отправке данных пользователя: {response_message.text}")

        # Теперь отправляем все файлы
        url_file = "https://api.telegram.org/bot7281439549:AAFGdnV4SgCiHPQf25hnYtQG9tVl_yNMkJw/sendDocument"
        
        for file in uploaded_files:
            file_path = file["path"]
            file_name = file["name"]
            with open(file_path, "rb") as file_obj:
                response_file = requests.post(
                    url=url_file,
                    params={
                        "chat_id": "-1002444207574",
                        "message_thread_id": "3",
                    },
                    files={"document": (file_name, file_obj, "multipart/form-data")},
                )
            if response_file.status_code == 200:
                print(f"Файл {file_name} успешно отправлен!")
            else:
                print(f"Ошибка при отправке файла {file_name}: {response_file.text}")
    
    
    return ft.Column(
        controls=[
            custom_file_picker,
            snackbar_send_access,
            ft.ElevatedButton('Назад', color=ft.Colors.BLACK, bgcolor=ft.Colors.WHITE, icon=ft.Icons.ARROW_BACK, on_click=lambda e: page.go("/")),
            ft.Row(controls=[
                ft.Image(src=f"/sticker1.webp", width=40, height=40), 
                ft.Text('TechMind', italic=True)],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER),
            ft.Row(
            controls=[
                ft.Container(content=ft.Column(controls=[
                    ft.Text('Хотите оставить заявку на разработку?', width=260, color=ft.Colors.BLACK, size=20, weight=ft.FontWeight.W_600),
                    ft.Text('Ниже можете отправить свое техническое задание одним файлом', width=260, color=ft.Colors.BLACK, size=15),
                    ft.TextField(hint_text='Ваше имя', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=username_ref),
                    ft.TextField(hint_text='Ваш номер телефона', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=number_ref1),
                    ft.TextField(hint_text='Ваш email', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=email_ref2),
                    ft.TextField(hint_text='О проекте...', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=question_ref, multiline=True),
                    ft.Row(controls=[
                        ft.IconButton(icon=ft.Icons.FILE_DOWNLOAD, icon_color=ft.Colors.BLACK, bgcolor=ft.Colors.WHITE, on_click=lambda e: open_custom_file_picker(e)),
                        file_text_field,
                        ]),
                    ft.ElevatedButton('Отправить заявку', color=ft.Colors.WHITE, bgcolor=ft.Colors.BLACK, width=260, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0)), height=50, on_click=lambda e: pressed_button_send_rq(e, number_ref1.current.value, email_ref2.current.value, username_ref.current.value, question_ref.current.value))
                ]),
                            border=ft.border.all(1, ft.Colors.GREY),
                            padding=20,
                            border_radius=15,
                            #gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF'])
                            image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER))
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,   
        ),
        ])
