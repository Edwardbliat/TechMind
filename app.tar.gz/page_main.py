import flet as ft
import requests

def fun_page_main(page: ft.Page):
    page.window.width = 430
    page.window.height = 932
    #Дополнительный контент к основе (ПЕРЕМЕННЫЕ)
    username_ref = ft.Ref[ft.TextField]()
    number_ref1 = ft.Ref[ft.TextField]()
    email_ref2 = ft.Ref[ft.TextField]()
    dlg_bot = ft.AlertDialog(content=ft.Column(controls=[ft.Column(controls=[
        ft.Container(content=ft.Column(controls=[
            ft.Text('Простая версия', theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, size=20, weight=ft.FontWeight.W_700),
            ft.Text('- Структурированное меню с кнопками (разделы, категории)', size=15, italic=True),
            ft.Text('- Простая форма обратной связи. Например, сбор имени, номера телефона и т.п.',  size=15, italic=True),
            ft.Text('- Отправка текстовых или мультимедийных сообщений (текст, фото, видео, документы)',  size=15, italic=True),
            ft.Text('20 000 - 50 000 ₽', size=24, weight=ft.FontWeight.W_600),
            ]),
                    border=ft.border.all(2, '#EEC6FF'),
                    border_radius=15,
                    padding=10),
        ft.Container(content=ft.Column(controls=[
            ft.Text('Средняя сложность',  size=20,  weight=ft.FontWeight.W_700),
            ft.Text('- Интеграция с CRM системами. Передача данных о клиентах (заявках) в AmoCRM, Bitrix24.',  size=15, italic=True),
            ft.Text('- Работа с базами данных.',  size=15, italic=True),
            ft.Text('- Личный кабинет пользователя и отслеживание статусов.',  size=15, italic=True),
            ft.Text('70 000 - 100 000₽', size=24, weight=ft.FontWeight.W_600),
        ]), 
                    border=ft.border.all(2, '#EEC6FF'),
                    border_radius=15,
                    padding=10),
        ft.Container(content=ft.Column(controls=[
            ft.Text('Сложная версия',  size=20,  weight=ft.FontWeight.W_700),
            ft.Text('- Поддержка цепочек бизнес-логики. Например, автоматизация нескольких бизнес-процессов: от оформления заказа до обработки возврата/поддержки.',  size=15, italic=True),
            ft.Text('- Чат-бот + MiniApp. Гибридные системы, где Telegram-бот выполняет функции MiniApp.',  size=15, italic=True),
            ft.Text('- Обработка больших массивов данных. Использование сложных алгоритмов, обработки больших данных, персонализации.', size=15, italic=True),  
            ft.Text('+120 000 ₽', size=24, weight=ft.FontWeight.W_600),
        ]),
                    border=ft.border.all(2, '#EEC6FF'),
                    border_radius=15,
                    padding=10),
        ft.Row(controls=[ft.ElevatedButton('Оставить заявку', bgcolor=ft.Colors.BLACK, color=ft.Colors.WHITE, width=200, height=55, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0)), on_click= lambda e: page.go('/send-request/'))],
                   alignment=ft.MainAxisAlignment.CENTER
            ),
        ],
                                                                   scroll=ft.ScrollMode.ALWAYS)]),
                             modal=False,
                             title=ft.Column(controls=[ft.ElevatedButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: close_dlg_bot(e), text='Назад', color=ft.Colors.BLACK, icon_color='#EEC6FF'), ft.Text('Разработка Telegram Bot', )]),
                             on_dismiss=lambda e: close_dlg_bot(e),
                             scrollable=True,
                             bgcolor=ft.Colors.WHITE)
    dlg_app = ft.AlertDialog(content=ft.Column(controls=[ft.Column(controls=[
        ft.Container(content=ft.Column(controls=[
            ft.Text('Простая версия', theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, size=20, weight=ft.FontWeight.W_700),
            ft.Text('- Разработка базового пользовательского интерфейса (UI)', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('- Формы для сбора данных- Отображение информации: витрина товаров или услуг с простой навигацией, Презентация расписаний, прайсов, информации о компании и акций.', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('- Минимальная интеграция', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('100 000 - 250 000 ₽', size=24, weight=ft.FontWeight.W_600),
            ]),
                    border=ft.border.all(2, '#EEC6FF'),
                    border_radius=15,
                    padding=10),
        ft.Container(content=ft.Column(controls=[
            ft.Text('Сложность выше простой',  size=20,  weight=ft.FontWeight.W_700),
            ft.Text('- Продвинутый фронтенд с кастомным дизайном.', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('- Работа с базами данных в реальном времени: подключение к вашим базам данных (PostgreSQL, MongoDB и т.п.) для хранения и получения информации. Личный кабинет пользователя: истории заказов, личные данные, изменения профиля.', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('- Динамическое взаимодействие с данными', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('+300 000 ₽', size=24, weight=ft.FontWeight.W_600),
            
        ]), 
                    border=ft.border.all(2, '#EEC6FF'),
                    border_radius=15,
                    padding=10),
        ft.Row(controls=[ft.ElevatedButton('Оставить заявку', bgcolor=ft.Colors.BLACK, color=ft.Colors.WHITE, width=200, height=55, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0)), on_click= lambda e: page.go('/send-request/'))],
                   alignment=ft.MainAxisAlignment.CENTER
            ),
        ],
                                                                   scroll=ft.ScrollMode.ALWAYS)]),
                             modal=False,
                             title=ft.Column(controls=[ft.ElevatedButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: close_dlg_app(e), text='Назад', color=ft.Colors.BLACK, icon_color='#EEC6FF'), ft.Text('Разработка Telegram MiniApp', )]),
                             on_dismiss=lambda e: close_dlg_app(e),
                             scrollable=True,
                             bgcolor=ft.Colors.WHITE)
    dlg_custom = ft.AlertDialog(content=ft.Column(controls=[ft.Column(controls=[
        ft.Container(content=ft.Column(controls=[
            ft.Text('Индивидуальное решение', theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, size=20, weight=ft.FontWeight.W_700),
            ft.Text('Разработка по индивидуальному запросу. Отправьте ваше ТЗ документом. С вами свяжутся для уточнения деталей и сориентируют по стоимости', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('Если у вас нет ТЗ, то перейдите по "Консультация" и мы Вам поможем с ТЗ', theme_style=ft.TextThemeStyle.HEADLINE_SMALL, size=15, italic=True),
            ft.Text('Стоимость договорная', size=22, weight=ft.FontWeight.W_600),
            ]),
                    border=ft.border.all(2, '#EEC6FF'),
                    border_radius=15,
                    padding=10),
        ft.Row(controls=[ft.ElevatedButton('Отправить ТЗ', bgcolor=ft.Colors.BLACK, color=ft.Colors.WHITE, width=200, height=55, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0)), on_click= lambda e: page.go('/send-request/'))],
                   alignment=ft.MainAxisAlignment.CENTER
            ),
        ],
                                                                   scroll=ft.ScrollMode.ALWAYS)]),
                             modal=False,
                             title=ft.Column(controls=[ft.ElevatedButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: close_dlg_custom(e), text='Назад', color=ft.Colors.BLACK, icon_color='#EEC6FF'), ft.Text('Индивидуальные IT-решения', )]),
                             on_dismiss=lambda e: close_dlg_custom(e),
                             scrollable=True,
                             bgcolor=ft.Colors.WHITE)
    snackbar_send_access = ft.SnackBar( 
                                       content=ft.Text('Отлично! Мы получили вашу заявку и в скором времени с вами свяжется наш менеджер', color=ft.Colors.WHITE),
                                       bgcolor=ft.Colors.BLACK,
                                       duration=10000,
                                       )
    custom_file_picker = ft.FilePicker(on_result=lambda e: on_files_selected(e))
    uploaded_files = []
    file_list = ft.Column()
    file_text_field = ft.TextField(
        hint_text='Ваше ТЗ',
        width=210,
        bgcolor=ft.Colors.WHITE,
        border_color=ft.Colors.GREY,
        value="",)
    icon_scroll_forward = ft.IconButton(icon=ft.Icons.ARROW_FORWARD, on_click=lambda e: scroll_to_offset_forward(e), icon_color=ft.Colors.BLACK, selected=True)
    icon_scroll_back = ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: scroll_to_offset_back(e), icon_color=ft.Colors.BLACK)
    row_image = ft.Row(controls=
                        [
                            ft.Image(src="/intro2.jpg"),
                            ft.Image(src="/intro4.jpg"),
                            ft.Image(src="/intro1.jpg"),
                            ft.Image(src="/intro3.jpg"),
                        ],
                        scroll=ft.ScrollMode.ALWAYS,
                        height=250,
                        )
    #Дополнительный контент к основе (ФУНКЦИИ)
    def on_files_selected(e):
        if e.files:
            uploaded_files.clear()  # Очищаем список для работы с новым файлом
            for f in e.files:
                uploaded_files.append({"name": f.name, "path": f.path})
            update_file_list()
            update_text_field()  # Задаем новое значение в TextField
            page.update()
    
    
    def update_text_field():
    # Устанавливаем название файлов в TextField через запятую
        if uploaded_files:
            file_text_field.value = ", ".join([f["name"] for f in uploaded_files])
        else:
            file_text_field.value = ""
    
    
    def update_file_list():
        file_list.controls.clear()  # Очистить старый список
        for file in uploaded_files:
            file_list.controls.append(
                ft.Row(
                    [
                        ft.Text(file["name"], expand=True),  # Отображаем имя файла
                        ft.IconButton(
                            icon=ft.Icons.DELETE,
                            tooltip="Удалить",
                        ),
                    ]
                )
            )
        page.update()
    
    def open_custom_file_picker(e):
            custom_file_picker.pick_files(allow_multiple=True)
            page.update()
    
    
    
    def open_dlg_bot(e):
        dlg_bot.open = True
        page.update()

    
    def close_dlg_bot(e):
        dlg_bot.open = False
        page.update()

    def open_dlg_app(e):
        dlg_app.open = True
        page.update()
        
    def close_dlg_app(e):
        dlg_app.open = False
        page.update()
        
    def open_dlg_custom(e):
        dlg_custom.open = True
        page.update()
        
    def close_dlg_custom(e):
        dlg_custom.open = False
        page.update()
    
    def pressed_button_send_rq(e, number, email, username):
    # Отправка пользовательских данных
        data = f"Заявка с MiniApp\n\nИмя клиента: {username}\nНомер телефона: {number}\nПочта: {email}"
        url_message = "https://api.telegram.org/bot7281439549:AAFGdnV4SgCiHPQf25hnYtQG9tVl_yNMkJw/sendMessage"
        
        response_message = requests.post(
            url=url_message, 
            params={
                "chat_id": "-1002444207574",
                "message_thread_id": "3",
                "text": data,
            }
        )
        if response_message.status_code == 200:
            print("Данные пользователя успешно отправлены!")
            snackbar_send_access.open = True
            page.update()
        else:
            print(f"Ошибка при отправке данных пользователя: {response_message.text}")

        # Теперь отправляем все файлы
        url_file = "https://api.telegram.org/bot7281439549:AAFGdnV4SgCiHPQf25hnYtQG9tVl_yNMkJw/sendDocument"
        
        for file in uploaded_files:
            file_path = file["path"]
            file_name = file["name"]
            with open(file_path, "rb") as file_obj:
                response_file = requests.post(
                    url=url_file,
                    params={
                        "chat_id": "-1002444207574",
                        "message_thread_id": "3",
                    },
                    files={"document": (file_name, file_obj, "multipart/form-data")},
                )
            if response_file.status_code == 200:
                print(f"Файл {file_name} успешно отправлен!")
            else:
                print(f"Ошибка при отправке файла {file_name}: {response_file.text}")
    
    #Скролл INNTROIMAGE    
    def scroll_to_offset_forward(e):
        row_image.scroll_to(offset=-1, duration=10000)
    
    def scroll_to_offset_back(e):
        row_image.scroll_to(offset=1, duration=10000)
    
    
    #Скролл Услуг
    def scroll_to_offset_forward_service(e):
        row_image.scroll_to(offset=-1, duration=10000)
    
    def scroll_to_offset_back_service(e):
        row_image.scroll_to(offset=1, duration=10000)
    
    #Скролл Разработки
    def scroll_to_offset_forward_product(e):
        row_image.scroll_to(offset=-1, duration=10000)
    
    def scroll_to_offset_back_product(e):
        row_image.scroll_to(offset=1, duration=10000)
    
    
    #Основа
    return ft.Column(controls=[
        snackbar_send_access,
        custom_file_picker,
        dlg_bot,
        dlg_app,
        dlg_custom,
        #Второй отсек
        ft.Column(controls=[
            ft.Text('Разработка Telegram Bot&MiniApp', theme_style=ft.TextThemeStyle.DISPLAY_MEDIUM, size=24, weight=ft.FontWeight.W_500),
            ft.Text(''),
            ft.Row(controls=[icon_scroll_back, icon_scroll_forward], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            row_image,
             ],
                  alignment=ft.MainAxisAlignment.CENTER,
                  horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        #Третий отсек
        ft.Text(''),
        ft.Container(content=
            ft.Container(content=ft.Column(controls=[
                ft.Text('Что мы предлагаем', size=24, theme_style=ft.TextThemeStyle.DISPLAY_MEDIUM, weight=ft.FontWeight.W_500),
                ft.Text('Мы создаем Telegram-боты и MiniApp под ваши задачи — от автоматизации, продаж, повышения вовлеченности клиентов до индивидуальных IT-решений', size=14, width=300, italic=True)
                ])),
            width=400,
            alignment=ft.alignment.top_left),
        ft.Text(''),
        ft.Row(controls=[
            #Первая колонка(BOT)
            ft.Container(content=ft.Column(controls=[
                ft.Container(content=ft.Image(src="/ботбот.jpg", width=290, height=120),width=290, border=ft.border.all(1, ft.Colors.WHITE), bgcolor=ft.Colors.WHITE),
                ft.Container(content=ft.Column(controls=[
                    ft.Text('Разработка Telegram-ботов под ключ:', theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, size=16),
                    ft.Text('- Автоматизация клиентской поддержки;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Приём заказов, онлайн-бронирование, доставка;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Интеграция с CRM и платежными системами;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Проведение опросов, уведомлений и рассылок;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Виртуальные помощники для сотрудников;',  size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Реализовываем ваши идеи',  size=13, italic=True, weight=ft.FontWeight.W_600),
                    ]),
                             padding=10,
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             margin=10,
                             border_radius=15,),
                ft.Row(controls=[ft.ElevatedButton(content=ft.Text('О разработке', size=16), style=ft.ButtonStyle(
                    color={
                        ft.ControlState.HOVERED: ft.Colors.WHITE,
                        ft.ControlState.FOCUSED: '#EEC6FF',
                        ft.ControlState.DEFAULT: ft.Colors.BLACK,
                    },
                    bgcolor={ft.ControlState.HOVERED: ft.Colors.BLACK,
                             ft.ControlState.DEFAULT: ft.Colors.WHITE},
                    elevation={"pressed": 0, "": 1},
                    animation_duration=500,
                    side={
                        ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.BLACK),
                        ft.ControlState.HOVERED: ft.BorderSide(1, '#EEC6FF'),
                    },
                    shape={
                        ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                        ft.ControlState.DEFAULT: ft.RoundedRectangleBorder(radius=2),
                    },
                ),
                                                   width=150, height=70, on_click=lambda e: open_dlg_bot(e))],
                       alignment=ft.MainAxisAlignment.CENTER,
                       height=35,),
                ]),
                         width=290,
                         bgcolor=ft.Colors.WHITE,
                         border=ft.border.all(2, '#EEC6FF'),
                         border_radius=10,
                         #gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER)),
            #Вторая колонка(MiniApp)
            ft.Container(content=ft.Column(controls=[
                ft.Container(content=ft.Image(src="/sticker3.webp", width=290, height=120),width=260, border=ft.border.all(1, ft.Colors.WHITE), bgcolor=ft.Colors.WHITE),
                ft.Container(content=ft.Column(controls=[
                    ft.Text('Создание Mini-App приложений для Telegram:', theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, size=16),
                    ft.Text('- Полноценный функционал без необходимости разработки отдельного мобильного приложения;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Гибкие интерфейсы для упрощения взаимодействия с клиентами;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Идеально подходит для онлайн-ритейла, образовательных платформ, маркетплейсов и других направлений', size=13, italic=True, weight=ft.FontWeight.W_600, height=105),
                    ]),
                             padding=10,
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             border_radius=15,
                             margin=10),
                ft.Row(controls=[ft.ElevatedButton(content=ft.Text('О разработке', size=16), style=ft.ButtonStyle(
                    color={
                        ft.ControlState.HOVERED: ft.Colors.WHITE,
                        ft.ControlState.FOCUSED: '#EEC6FF',
                        ft.ControlState.DEFAULT: ft.Colors.BLACK,
                    },
                    bgcolor={ft.ControlState.HOVERED: ft.Colors.BLACK,
                             ft.ControlState.DEFAULT: ft.Colors.WHITE},
                    #padding={ft.ControlState.HOVERED: 20},
                    #overlay_color='#EEC6FF',
                    elevation={"pressed": 0, "": 1},
                    animation_duration=500,
                    side={
                        ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.BLACK),
                        ft.ControlState.HOVERED: ft.BorderSide(1, '#EEC6FF'),
                    },
                    shape={
                        ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                        ft.ControlState.DEFAULT: ft.RoundedRectangleBorder(radius=2),
                    },
                ),
                                                   width=150, height=47, on_click=lambda e: open_dlg_app(e))],
                       alignment=ft.MainAxisAlignment.CENTER,
                       height=35),
                ]),
                         width=260,
                         bgcolor=ft.Colors.WHITE,
                         border=ft.border.all(2, '#EEC6FF'),
                         border_radius=10,
                         #gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER)),
            #Третья колонка(ИНДИВИДУАЛЬНЫЕ IT РЕШЕНИЯ)
            ft.Container(content=ft.Column(controls=[
                ft.Container(content=ft.Image(src="/sticker5.webp", height=120),width=290, border=ft.border.all(1, ft.Colors.WHITE), bgcolor=ft.Colors.WHITE),
                ft.Container(content=ft.Column(controls=[
                    ft.Text('Индивидуальные IT-решения:', theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM, size=16),
                    ft.Text('- Интеграция с любой системой: от аналитики до логистики;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Кастомизированные интерфейсы и функции;', size=13, italic=True, weight=ft.FontWeight.W_600),
                    ft.Text('- Полный цикл разработки: от разработки идеи до тестирования и запуска', size=13, italic=True, weight=ft.FontWeight.W_600, height=160),
                    ]),
                             padding=10,
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             border_radius=15,
                             margin=10),
                ft.Row(controls=[ft.ElevatedButton(content=ft.Text('О разработке', size=16), style=ft.ButtonStyle(
                    color={
                        ft.ControlState.HOVERED: ft.Colors.WHITE,
                        ft.ControlState.FOCUSED: '#EEC6FF',
                        ft.ControlState.DEFAULT: ft.Colors.BLACK,
                    },
                    bgcolor={ft.ControlState.HOVERED: ft.Colors.BLACK,
                             ft.ControlState.DEFAULT: ft.Colors.WHITE},
                    #padding={ft.ControlState.HOVERED: 20},
                    #overlay_color='#EEC6FF',
                    elevation={"pressed": 0, "": 1},
                    animation_duration=500,
                    side={
                        ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.BLACK),
                        ft.ControlState.HOVERED: ft.BorderSide(1, '#EEC6FF'),
                    },
                    shape={
                        ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                        ft.ControlState.DEFAULT: ft.RoundedRectangleBorder(radius=2),
                    },
                ),
                                                   width=150, height=47, on_click=lambda e: open_dlg_custom(e))],
                       alignment=ft.MainAxisAlignment.CENTER,
                       height=35),
                ]),
                         width=260,
                         bgcolor=ft.Colors.WHITE,
                         border=ft.border.all(2, '#EEC6FF'),
                         border_radius=10,
                         #gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER)),],
               scroll=ft.ScrollMode.ALWAYS,
               height=550),        
        #КНОПКА КОНСУЛЬТАЦИЯ БЕСПЛАТНО
        ft.Text(''),
        ft.Row(controls=[
                ft.ElevatedButton('Получить консультацию бесплатно', height=50, style=ft.ButtonStyle(
                    color={
                        ft.ControlState.HOVERED: ft.Colors.WHITE,
                        ft.ControlState.FOCUSED: '#EEC6FF',
                        ft.ControlState.DEFAULT: ft.Colors.WHITE,
                    },
                    bgcolor={ft.ControlState.HOVERED: '#EEC6FF',
                             ft.ControlState.DEFAULT: ft.Colors.BLACK},
                    elevation={"pressed": 0, "": 1},
                    animation_duration=500,
                    side={
                        ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.BLACK),
                        ft.ControlState.HOVERED: ft.BorderSide(1, '#EEC6FF'),
                    },
                    shape={
                        ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                        ft.ControlState.DEFAULT: ft.RoundedRectangleBorder(radius=2),
                    },
                ), on_click= lambda e: page.go('/create-request/'), width=300),
            ],
                   height=70,
                   alignment=ft.MainAxisAlignment.CENTER),
        ft.Text(''),
        
        #Секция ТАЙМЛАЙН ПРОЕКТА
        ft.Text(''),
        ft.Container(content=
            ft.Container(content=ft.Column(controls=[
                ft.Text('Разработка проекта', size=24, theme_style=ft.TextThemeStyle.DISPLAY_MEDIUM, weight=ft.FontWeight.W_500),
                ft.Text('В процессе разработки вашего проекта, приоритет отдается созданию чистого, интуитивно понятного взаимодействия с вашим продуктом, который визулизирует новым клиентам процесс пользования сервисом', size=14, width=300, italic=True)
                ])),
            width=400,
            alignment=ft.alignment.top_left),
        
        #Первая часть РАЗРАБОТКА ПРОЕКТА
        ft.Text(''),
        ft.Container(content=
            ft.Container(content=ft.Row(controls=[ft.Container(content=ft.Icon(name=ft.Icons.CONTENT_PASTE_SEARCH, color=ft.Colors.BLACK), bgcolor=ft.Colors.WHITE, border_radius=50, height=40, width=40, border=ft.border.all(2, "#EEC6FF")), ft.Text('Исследование')]), bgcolor="#EEC6FF", border_radius=25, width=160, height=40),
            width=400,
            alignment=ft.alignment.top_left),
        ft.Container(content=
            ft.Container(content=ft.Row(controls=[ft.Container(content=ft.Icon(name=ft.Icons.CODE, color=ft.Colors.BLACK), bgcolor=ft.Colors.WHITE, border_radius=50, height=40, width=40, border=ft.border.all(2, "#EEC6FF")), ft.Text('Разработка')]), bgcolor="#EEC6FF", border_radius=25, width=160, height=40),
            width=400,
            alignment=ft.alignment.Alignment(-0.35, -0.5)),
        ft.Container(content=
            ft.Container(content=ft.Row(controls=[ft.Container(content=ft.Icon(name=ft.Icons.REMOVE_RED_EYE, color=ft.Colors.BLACK), bgcolor=ft.Colors.WHITE, border_radius=50, height=40, width=40, border=ft.border.all(2, "#EEC6FF")), ft.Text('Тестирование')]), bgcolor="#EEC6FF", border_radius=25, width=160, height=40),
            width=400,
            alignment=ft.alignment.Alignment(0.30, -0.5)),
        ft.Container(content=
            ft.Container(content=ft.Row(controls=[ft.Container(content=ft.Icon(name=ft.Icons.SEND_AND_ARCHIVE_SHARP, color=ft.Colors.BLACK), bgcolor=ft.Colors.WHITE, border_radius=50, height=40, width=40, border=ft.border.all(2, "#EEC6FF")), ft.Text('Передача')]), bgcolor="#EEC6FF", border_radius=25, width=160, height=40),
            width=400,
            alignment=ft.alignment.Alignment(0.95, -0.5)),
        ft.Text(''),
        #Вторая часть РАЗРАБОТКА ПРОЕКТА
        ft.Row(controls=[
            ft.Container(content=ft.Column(controls=[
                ft.Row(controls=[ft.Text('Исследование', size=17, weight=ft.FontWeight.W_500), ft.IconButton(content=ft.Icon(ft.Icons.ARROW_OUTWARD, color=ft.Colors.BLACK, size=20), bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE), icon_color=ft.Colors.BLACK)], height=50, alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Container(content=ft.Column(controls=[ft.Text('-Анализ потребностей', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Брифинг', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Техническое задание', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Анализ конкурентов', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ]),
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             border_radius=10,
                             width=165,
                             height=180,
                             padding=10,
                             image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER))
            ]),
                         gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         border_radius=15,
                         width=185,
                         height=270,
                         padding=10),
            ft.Container(content=ft.Column(controls=[
                ft.Row(controls=[ft.Text('Разработка', size=17, weight=ft.FontWeight.W_500), ft.IconButton(content=ft.Icon(ft.Icons.ARROW_OUTWARD, color=ft.Colors.BLACK, size=20), bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE), icon_color=ft.Colors.BLACK)], height=50, alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Container(content=ft.Column(controls=[ft.Text('-Прототип', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Архитектура', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Дизайн система', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Брифинг', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ]),
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             border_radius=10,
                             width=175,
                             height=180,
                             padding=10,
                             image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER))
            ]),
                         gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         border_radius=15,
                         width=185,
                         height=270,
                         padding=10),
            ft.Container(content=ft.Column(controls=[
                ft.Row(controls=[ft.Text('Тестирование', size=17, weight=ft.FontWeight.W_500), ft.IconButton(content=ft.Icon(ft.Icons.ARROW_OUTWARD, color=ft.Colors.BLACK, size=20), bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE), icon_color=ft.Colors.BLACK)], height=50, alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Container(content=ft.Column(controls=[ft.Text('-Корректировки', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Доработка', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Тестирование', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ]),
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             border_radius=10,
                             width=165,
                             height=180,
                             padding=10,
                             image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER))
            ]),
                         gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         border_radius=15,
                         width=185,
                         height=270,
                         padding=10),
            ft.Container(content=ft.Column(controls=[
                ft.Row(controls=[ft.Text('Передача', size=17, weight=ft.FontWeight.W_500), ft.IconButton(content=ft.Icon(ft.Icons.ARROW_OUTWARD, color=ft.Colors.BLACK, size=20), bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE), icon_color=ft.Colors.BLACK)], height=50, alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Container(content=ft.Column(controls=[ft.Text('-Брифинг', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Передача проекта', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ft.Text('-Деплой', size=12, weight=ft.FontWeight.W_500, italic=True),
                                                         ]),
                             bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.WHITE),
                             border_radius=10,
                             width=165,
                             height=180,
                             padding=10,
                             image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER))
            ]),
                         gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF']),
                         border_radius=15,
                         width=185,
                         height=270,
                         padding=10),
            ],
               scroll=ft.ScrollMode.ALWAYS,
               vertical_alignment=ft.CrossAxisAlignment.CENTER),
        #Секция отзывов
        ft.Text(''),
        ft.Column(controls=[
            ft.Text('Отзывы о нас', size=24, theme_style=ft.TextThemeStyle.DISPLAY_MEDIUM, weight=ft.FontWeight.W_500),
            ft.Column(controls=[
                ft.Container(content=ft.Column(controls=[
                    ft.Row(controls=[
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.WHITE),
                    ]),
                    ft.Text('"Очень выручили с Ботом. Как раз попал на Вас перед тем, как запустили рекламу"', italic=True, weight=ft.FontWeight.W_600),
                    ft.CircleAvatar(content=ft.Icon(ft.Icons.ABC), bgcolor=ft.Colors.WHITE),
                    ft.Text('Noname', size=12),
                    ft.Text('Разработка Telegram Bot "Под ключ"')]), border=ft.border.all(1, ft.Colors.GREY), padding=10, border_radius=15),
                ft.Container(content=ft.Column(controls=[
                    ft.Row(controls=[
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ]),
                    ft.Text('"Хорошо проконсультировал 👌 теперь ясно что делать дальше"', italic=True, weight=ft.FontWeight.W_600),
                    ft.CircleAvatar(content=ft.Image(src="/отзыв1.jpg", border_radius=40)),
                    ft.Text('Edward12', size=12),
                    ft.Text('Проконсультировали по вопросу MiniApp')
                    ]), border=ft.border.all(1, ft.Colors.GREY), padding=10,  border_radius=15),
                ft.Container(content=ft.Column(controls=[
                    ft.Row(controls=[
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.WHITE),
                    ]),
                    ft.Text('"Я частный предприниматель, мне было просто необходимо приложение для моего бизнеса. Человек уложился во все сроки и разработал крутое приложение, приятно удивлен, узнав на сколько классно это всё работает."', italic=True, weight=ft.FontWeight.W_600),
                    ft.CircleAvatar(content=ft.Icon(ft.Icons.ABC)),
                    ft.Text('Alex27An', size=12),
                    ft.Text('Разработка Telegram Bot "Под ключ"')
                ]), border=ft.border.all(1, ft.Colors.GREY), padding=10,  border_radius=15),
                ft.Container(content=ft.Column(controls=[
                    ft.Row(controls=[
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ft.Icon(name = ft.Icons.STAR, color=ft.Colors.YELLOW),
                    ]),
                    ft.Text('"Выражаем благодарность от всей нашей команды. Сотрудничество прошло прекрасно ❤️"',  italic=True, weight=ft.FontWeight.W_600),
                    ft.CircleAvatar(content=ft.Image(src="/отзыв2.jpg", border_radius=40)),
                    ft.Text('Елена', size=12),
                    ft.Text('Разработка Telegram Bot "Под ключ"')
                    ]), border=ft.border.all(1, ft.Colors.GREY), padding=10,  border_radius=15),
            ]),
            ft.Text('')
        ]),
        #ФОРМА ЗАПОЛНЕНИЯ С ТЗ
        ft.Text(''),
        ft.Row(
            controls=[
                ft.Container(content=ft.Column(controls=[
                    ft.Text('Хотите обсудить ваш проект? Напишите нам!', width=260, color=ft.Colors.BLACK, size=20, weight=ft.FontWeight.W_600),
                    ft.Text('Ниже можете отправить свое техническое задание одним файлом', width=260, color=ft.Colors.BLACK, size=15),
                    ft.TextField(hint_text='Ваше имя', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=username_ref),
                    ft.TextField(hint_text='Ваш номер телефона', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=number_ref1),
                    ft.TextField(hint_text='Ваш email', width=260, bgcolor=ft.Colors.WHITE, border_color=ft.Colors.GREY, ref=email_ref2),
                    ft.Row(controls=[
                        ft.IconButton(icon=ft.Icons.FILE_DOWNLOAD, icon_color=ft.Colors.BLACK, bgcolor=ft.Colors.WHITE, on_click=lambda e: open_custom_file_picker(e)),
                        file_text_field,
                        ]),
                    ft.ElevatedButton('Отправить заявку', color=ft.Colors.WHITE, bgcolor=ft.Colors.BLACK, width=260, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0)), height=50, on_click=lambda e: pressed_button_send_rq(e, number_ref1.current.value, email_ref2.current.value, username_ref.current.value))
                ]),
                            border=ft.border.all(1, ft.Colors.GREY),
                            padding=20,
                            border_radius=15,
                            #gradient=ft.LinearGradient(begin=ft.alignment.top_center, end=ft.alignment.bottom_center, colors=['#D1C0FF', '#EDC3FF'])
                            image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER))
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,   
        ),
        ft.Text(''),
        ft.Container(content=ft.Column(controls=[
            ft.Text('Мы — команда профессионалов с опытом разработки мини‑приложений и Telegram‑ботов для бизнеса', size=16, weight=ft.FontWeight.W_500, italic=True, width=320),
            ft.Text('Ваш бизнес — наш приоритет!', size=16, weight=ft.FontWeight.W_500, italic=True, width=320),
            ],
                                       horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                       alignment=ft.MainAxisAlignment.CENTER),
                     image=ft.DecorationImage(src="/бэк2.jpg", fit=ft.ImageFit.COVER),
                     height=300, width=550,
                     alignment=ft.alignment.center,
                     margin=0),
#Заключение доп.контролера сверху
####Главный контролер снизу.        
    ],
                     alignment=ft.MainAxisAlignment.CENTER,
                     horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                     scroll=ft.ScrollMode.ALWAYS,
                     expand=True,
                     tight=True)
