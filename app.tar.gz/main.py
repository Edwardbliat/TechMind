import flet as ft
import page_collaboration, page_request, page_main, page_request_TZ




##############            FLET UI/UX
def main(page: ft.Page):
    page.title = 'TechMind'
    page.window.width = 430
    page.window.height = 932
    page.theme_mode = ft.ThemeMode.LIGHT
    


    
   
    
    
    def route_change(route):
        page.views.clear()
        if page.route == "/":
            page.controls.clear()
            page.window.height = 4000
            page.views.append(
                ft.View(
                    "/",
                    [
                        page_main.fun_page_main(page)
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    vertical_alignment=ft.MainAxisAlignment.CENTER,
                    bgcolor=ft.Colors.WHITE,
                )
            )
            page.update()
        if page.route == "/create-request/":
            page.controls.clear()
            page.views.append(
                ft.View(
                    '/create-request/',
                    [
                        page_request.fun_page_request(page)
                    ],
                    scroll=ft.ScrollMode.HIDDEN,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    vertical_alignment=ft.MainAxisAlignment.CENTER,
                )
            )
            page.update()
        if page.route == (f"/send-request/"):
            page.views.append(
                ft.View(
                    "/send-request/",
                    [
                        page_request_TZ.fun_page_request_TZ(page)
                    ],
                    scroll=ft.ScrollMode.HIDDEN,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    vertical_alignment=ft.MainAxisAlignment.CENTER
                )
            )
        page.update()

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go('/')

    
    page.on_route_change = route_change
    #page.on_view_pop = view_pop
    page.go("/")

    
ft.app(main, assets_dir="assets", web_renderer=ft.WebRenderer.HTML, port='0.0.0.0')
